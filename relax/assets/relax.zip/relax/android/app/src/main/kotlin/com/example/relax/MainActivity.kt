package com.example.relax

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
